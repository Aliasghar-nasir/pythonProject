from distutils.core import setup
setup(
        name = 'CalculatorAli',
        version = '1.0',
        py_modules = ['CalculatorAli'],
        author = 'Muhammad Ali Asghar',
        author_email = 'ali.asghar@brightnexus.com',
        description = 'Performs basic calculation operations',
        )
